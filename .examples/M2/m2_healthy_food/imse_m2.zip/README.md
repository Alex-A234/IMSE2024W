# Milestone 2: Nutrition Plan Application

*[052400 VU Information Management & Systems Engineering (2021W)](https://ufind.univie.ac.at/en/course.html?lv=052400&semester=2021W)*


> Abstract

The goal of our software system is to combine different aspects from 
health, nutrition, and fitness apps in one single platform. We help users to 
create optimal meal plans from a scientific perspective, which help them 
archive their fitness goals. 


> Technology stack

- Web framework: [Python-Flask](https://flask.palletsprojects.com/en/2.0.x/)
- DBMS: [SQLite](https://www.sqlite.org/index.html) and [MongoDB](https://www.mongodb.com/cloud/atlas/lp/try2?utm_source=google&utm_campaign=gs_footprint_row_search_core_brand_atlas_desktop&utm_term=mongodb&utm_medium=cpc_paid_search&utm_ad=e&utm_ad_campaign_id=12212624584&adgroup=115749713703&gclid=EAIaIQobChMIlrWG4JPt9AIVC553Ch2sSwQLEAAYASAAEgIf7fD_BwE)
- Deployment: [Docker](https://www.docker.com/)
- Version control: [GitHub](https://github.com/lgru/imse_m2)
- Documentation: [LaTeX](https://www.latex-project.org/)

> Launch with Docker

- Build images and start container `$ docker-compose up -d`
- Visit https://localhost:5000/
- Stop and remove container `$ docker-compose down`
- Clean up docker (including images and volumes) `$ docker system prune --all`

## Project Management

- [x] **Week 0**
    - [x] Launch basic Flask application, see [Flask Tutorial](https://www.youtube.com/watch?v=MwZwr5Tvyxo&list=PL-osiE80TeTs4UjLw5MM6OjgkjFeUxCYH&index=1)
    - [x] Install Docker, see https://www.docker.com/products/docker-desktop
    - [x] Launch application using Docker, see [Docker Tutorial](https://www.youtube.com/watch?v=wrMJoKpK2mk&t=309s)
    - [x] Create Git repo, see https://github.com/lgru/imse_m2
- [x] **Week 1**
    - [x] Finalize blueprint version
    - [x] User login and register (use-case 1)
    - [x] User profile completion
    - [x] Create SQL database
    - [x] Fill database with sample data
- [x] **Week 2**
    - [x] Create new meals (use-case 2)
    - [x] Search for meals (use-case 3)
    - [x] Get suggestions (use-case 4)
    - [x] Schedule meals (use-case 5)
    - [x] Implement Report 1
    - [x] Implement Report 2
    - [x] Implement database reset button
- [x] **Week 3**
    - [x] Implement migration button to switch to mongodb
    - [x] Install MongoDB Compass Community locally, see [Youtube Tutorial](https://www.youtube.com/watch?v=D0U8vD8m1I0)
    - [x] Run Mongo with Python, see [Youtube Tutorial](https://www.youtube.com/watch?v=YbLzV90dksE&t=74s)
    - [x] Write first test_migration function (create user and show results on home page)
    - [x] Setup mongo in docker file (created .yml file)
    - [x] NoSQL migration of users, meals, groceries, stores
    - [x] Start report for SQL part
- [x] **Week 4**
    - [x] For each function in [database_functions.py](https://github.com/lgru/imse_m2/blob/main/app/lib/database_functions.py)
        write an equivalent mongo version
    - [x] Implement both reports in NoSQL
    - [x] Implement MySQL connection instead of SQLite
    - [x] Include on-the-fly certificates to serve app over HTTPS
- [x] **Week 5**
    - [x] Test all use-cases (SQL & NoSQL)
    - [x] Test all reports (SQL & NoSQL)
    - [x] Finalize M2 report
    - [x] Finalize PowerPoint presentation
    - [x] Upload everything on Moodle (Deadline 1/18/2022)
