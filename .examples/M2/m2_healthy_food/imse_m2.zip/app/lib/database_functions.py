import pandas as pd
import numpy as np
import datetime as dt


def db_query_first_user(db, mongo_db, username=None, email=None):
    """ return user dictionary by name or email. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        if username:
            sql = f"select * from user where lower(username) = '{username.lower()}'"
        else:
            sql = f"select * from user where lower(email) = '{email.lower()}'"
        res = pd.read_sql_query(sql=sql, con=db).to_dict(orient='records')
        return res[0] if res else None

    # MongoDB query
    else:
        return mongo_db['user'].find_one({'$or': [{'username': username}, {'email': email}]}, {'schedules': 0})


def db_insert_new_user(db, mongo_db, form, recommend_id=None):
    """ writes new user into database. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        if recommend_id:
            sql = "INSERT INTO user (username, email, password, recommended_by) VALUES ('%s', '%s', '%s', %d);" % (
                form.username.data, form.email.data, form.password.data, recommend_id)
        else:
            sql = "INSERT INTO user (username, email, password) VALUES ('%s', '%s', '%s');" % (
                form.username.data, form.email.data, form.password.data)
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        return None

    # MongoDB query
    else:
        last_user = mongo_db['user'].find().sort('_id', -1).limit(1).__getitem__(0)
        mongo_db['user'].insert_one({
            '_id': last_user['_id'] + 1,
            'username': form.username.data,
            'email': form.email.data,
            'password': form.password.data,
            'favorite_store': 1,
            'recommended_by': recommend_id
        })
        return None


def db_update_current_user(db, mongo_db, username, form):
    """ updates profile information for current user. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"""
                UPDATE user
                SET favorite_store = {form.favorite_store.data}, 
                    gender = {"'%s'" % form.gender.data if form.gender.data != 'None' else 'NULL'},
                    birthday = {"'%s'" % pd.to_datetime(form.birthday.data).date() if form.birthday.data else 'NULL'}, 
                    height = {form.height.data if form.height.data else 'NULL'},
                    weight = {form.weight.data if form.weight.data else 'NULL'}, 
                    activity_level = {"'%s'"% form.activity_level.data if form.activity_level.data!='None' else 'NULL'}, 
                    personal_goal = {"'%s'" % form.personal_goal.data if form.personal_goal.data != 'None' else 'NULL'}
                WHERE username = '{username}'
                """
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        cursor.close()
        return None

    # MongoDB query
    else:
        query = {'username': username}
        updates = {'favorite_store': int(form.favorite_store.data),
                   'gender': form.gender.data,
                   'birthday': pd.to_datetime(form.birthday.data),
                   'height': form.height.data,
                   'weight': form.weight.data,
                   'activity_level': form.activity_level.data,
                   'personal_goal': form.personal_goal.data}
        mongo_db['user'].update_one(query, {'$set': updates})
        return None


def db_query_first_meal(db, mongo_db, name):
    """ query meal by name for detailed meal page. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"select * from meal where lower(name) = '{name.lower()}'"
        res = pd.read_sql_query(sql=sql, con=db).to_dict(orient='records')
        if res:
            return res[0]
        else:
            return dict()

    # MongoDB query
    else:
        return mongo_db['meal'].find_one({'name': name})


def db_create_new_meal(db, mongo_db, user_id, form):
    """ writes new meal with its ingredients into database. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = "INSERT INTO meal (name, category, servings, instructions, created_by) VALUES ('%s','%s',%d,'%s',%d);" % (
            form.name.data, form.category.data, form.servings.data, form.instructions.data.replace("'", r"\'"), user_id
        )
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()

        # ensure that we don't add same ingredients multiple times (rather store cumulative quantities)
        ingredients = {}
        i = 1
        while form[f'ingredient{i}'].data:
            if form[f'quantity{i}'].data > 0:
                ingredients[form[f'ingredient{i}'].data] = ingredients.get(form[f'ingredient{i}'].data, 0) \
                                                           + form[f'quantity{i}'].data
            i += 1

        # query new meal id
        df = pd.read_sql_query(f"select id from meal where name = '{form.name.data}'", con=db)
        meal_id = df['id'].values[0]

        # save ingredients
        sql = "INSERT INTO ingredient (meal_id, grocery_id, quantity) VALUES"
        for ingredient, quantity in ingredients.items():
            sql += " (%d, %d, %.2f)," % (meal_id, int(ingredient), quantity)
        cursor.execute(sql[:-1] + ';')
        db.commit()
        cursor.close()
        return meal_id

    # MongoDB query
    else:
        ingredients = {}
        i = 1
        # ensure that we don't add same ingredients multiple times (rather store cumulative quantities)
        while form[f'ingredient{i}'].data:
            if form[f'quantity{i}'].data > 0:
                ingredients[form[f'ingredient{i}'].data] = ingredients.get(form[f'ingredient{i}'].data, 0) \
                                                           + form[f'quantity{i}'].data
            i += 1

        # prepare dataframe to compute key meal summaries
        groceries = pd.DataFrame(list(mongo_db['grocery'].find({'_id': {'$in': [int(k) for k in ingredients.keys()]}})))
        groceries['meal_quantity'] = groceries['_id'].map({int(k): v for k, v in ingredients.items()})

        # get meal prices by store
        result = {}
        for i, grocery_prices in enumerate(groceries.prices):
            for store_price in grocery_prices:
                result.setdefault(store_price.get('store_id'), []).append(
                    store_price.get('price') * groceries.iloc[i]['meal_quantity'] / groceries.iloc[i]['quantity'])
        prices = []
        for k, values in result.items():
            if len(values) == len(groceries):
                prices.append({'store_id': k, 'price': round(sum(values), 2)})

        # add new meal with aggregated ingredients
        last_meal = mongo_db['meal'].find().sort('_id', -1).limit(1).__getitem__(0)
        mongo_db['meal'].insert_one({
            '_id': last_meal['_id'] + 1,
            'name': form.name.data,
            'category': form.category.data,
            'servings': form.servings.data,
            'kcal': groceries.eval('(4 * protein + 4 * carbohydrate + 9 * fat) / quantity * meal_quantity').sum(),
            'protein': groceries.eval('protein / quantity * meal_quantity').sum(),
            'carbohydrate': groceries.eval('carbohydrate / quantity * meal_quantity').sum(),
            'fat': groceries.eval('fat / quantity * meal_quantity').sum(),
            'is_vegan': True if type(groceries['is_vegan'].all()) else None,
            'instructions': form.instructions.data,
            'prices': prices,
            'created_by': user_id,
            'created_on': dt.datetime.now(),
            'ingredients': [{'grocery_id': int(g), 'quantity': q} for g, q in ingredients.items()]
        })
        return last_meal['_id'] + 1


def db_add_to_schedule(db, mongo_db, user_id, meal_id, scheduled_on):
    """ add a new meal to the plan. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = "INSERT INTO schedule (user_id, meal_id, scheduled_on) VALUES (%d, %d, '%s');" % (
            user_id, meal_id, pd.to_datetime(scheduled_on).date()
        )
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        cursor.close()
        return None

    # MongoDB query
    else:
        meal = mongo_db['meal'].find_one({'_id': meal_id})
        cat = meal.get('category')
        veg = meal.get('is_vegan')
        mongo_db['schedule'].insert_one({'user_id': user_id, 'meal_id': meal_id, 'category': cat, 'is_vegan': veg,
                                         'scheduled_on': pd.to_datetime(scheduled_on)})
        return None


def db_remove_from_schedule(db, mongo_db, user_id, meal_id, scheduled_on):
    """ remove scheduled meal. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"""DELETE FROM schedule 
            WHERE 0=0
                and user_id = {user_id}
                and meal_id = {meal_id}
                and scheduled_on = '{pd.to_datetime(scheduled_on).date()}'
            """
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        cursor.close()
        return None

    # MongoDB query
    else:
        mongo_db['schedule'].delete_one({'user_id': user_id, 'meal_id': meal_id,
                                         'scheduled_on': pd.to_datetime(scheduled_on)})
        return None


def db_delete_meal(db, mongo_db, meal_id):
    """ delete meal from database (only for admins). """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"DELETE FROM meal WHERE id = {meal_id}"
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        cursor.close()
        return None

    # MongoDB query
    else:
        mongo_db['meal'].delete_one({'_id': meal_id})
        mongo_db['schedule'].delete_many({'meal_id': meal_id})
        return None


def get_the_aggregate(data, column, dic):
    """ mongo helper function to get aggregated grocery summary """
    if column == 'ingredients':
        return ','.join([dic.get(d['grocery_id']).get('name') for d in data])
    elif column == 'quantities':
        return ','.join([str(d['quantity']) for d in data])
    elif column == 'measures':
        return ','.join([dic.get(d['grocery_id']).get('measure') for d in data])
    elif column == 'is_vegan':
        return int(all([dic.get(d['grocery_id']).get('is_vegan') for d in data]))
    else:
        return sum([
            d['quantity'] / dic.get(d['grocery_id']).get('quantity') * dic.get(d['grocery_id']).get(column)
            for d in data
            if dic.get(d['grocery_id']).get(column)
        ])


def db_query_meals(db, mongo_db, user_id):
    """ returns pandas dataframe as overview on meals page. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f'''
            select 
                m.id as meal_image,
                m.name as meal, 
                m.category,
                group_concat(g.name) as ingredients,
                cast(
                    (4 * sum(i.quantity / g.quantity * g.protein)
                    + 4 * sum(i.quantity / g.quantity * g.carbohydrate)
                    + 9 * sum(i.quantity / g.quantity * g.fat)
                    ) / m.servings as unsigned) as kcal,
                round(sum(i.quantity / g.quantity * g.protein) / m.servings, 1) as protein,
                round(sum(i.quantity / g.quantity * g.carbohydrate) / m.servings, 1) as carbs,
                round(sum(i.quantity / g.quantity * g.fat) / m.servings, 1) as fat,
                case when sum(case when p.price is null then 1 else 0 end) = 0
                    then round(sum(i.quantity / g.quantity * p.price) / m.servings, 2) 
                    else null end as price
            from
                meal m
                inner join ingredient i on i.meal_id = m.id
                inner join grocery g on g.id = i.grocery_id
                left outer join prices p on p.grocery_id = g.id 
                    and p.store_id = (select uu.favorite_store from user uu where uu.id = {user_id})
            group by m.id, m.name, m.category, m.servings, m.created_on
            order by m.id desc
        '''
        return pd.read_sql_query(sql=sql, con=db)

    # MongoDB query
    else:
        """ query meal summary list """
        # get favorite store
        store_id = mongo_db['user'].find_one({'_id': user_id}).get('favorite_store')

        # get grocery dictionary
        df_grocery = pd.DataFrame(data=list(mongo_db['grocery'].find()))
        df_grocery['price'] = df_grocery.prices.apply(
            lambda x: float(''.join([str(s['price']) for s in x if int(s['store_id']) == int(store_id)]) or np.nan))
        dict_grocery = df_grocery.set_index('_id').to_dict(orient='index')

        # get meals
        df_meal = pd.DataFrame(data=list(mongo_db['meal'].find().sort('_id', -1)),
                               columns=['_id', 'name', 'category', 'servings', 'ingredients'])
        df_meal.rename(columns={'_id': 'meal_image', 'name': 'meal', 'ingredients': 'data'}, inplace=True)

        # compute meal summary
        df_meal['ingredients'] = df_meal.data.apply(lambda x: get_the_aggregate(x, 'ingredients', dict_grocery))
        df_meal['protein'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'protein', dict_grocery)) / df_meal['servings'], 1)
        df_meal['carbs'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'carbohydrate', dict_grocery)) / df_meal['servings'], 1)
        df_meal['fat'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'fat', dict_grocery)) / df_meal['servings'], 1)
        df_meal['kcal'] = (4 * df_meal['protein'] + 4 * df_meal['carbs'] + 9 * df_meal['fat']).astype(int)
        df_meal['price'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'price', dict_grocery)) / df_meal['servings'], 2)
        return df_meal[['meal_image', 'meal', 'category', 'ingredients', 'kcal', 'protein', 'carbs', 'fat', 'price']]


def db_query_meal_details(db, mongo_db, meal_id, user_id):
    """ returns details for individual meal pages. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f'''
            select 
                m.id as meal_id,
                m.name, 
                m.category,
                m.instructions,
                m.servings,
                case when sum(g.is_vegan) = count(g.is_vegan) then 1 else 0 end as is_vegan,
                group_concat(g.name) as ingredients,
                group_concat(i.quantity) as quantities, 
                group_concat(g.measure) as measures, 
                round(sum(i.quantity / g.quantity * g.protein) / m.servings, 1) as protein,
                round(sum(i.quantity / g.quantity * g.carbohydrate) / m.servings, 1) as carbs,
                round(sum(i.quantity / g.quantity * g.fat) / m.servings, 1) as fat,
                cast(
                    (4 * sum(i.quantity / g.quantity * g.protein)
                    + 4 * sum(i.quantity / g.quantity * g.carbohydrate)
                    + 9 * sum(i.quantity / g.quantity * g.fat)
                    ) / m.servings as unsigned) as kcal,
                case when sum(case when p.price is null then 1 else 0 end) = 0
                    then round(sum(i.quantity / g.quantity * p.price) / m.servings, 2)
                    else null end as price,
                m.created_on,
                u.username as created_by
            from
                meal m
                inner join ingredient i on i.meal_id = m.id
                inner join grocery g on g.id = i.grocery_id
                inner join user u on u.id = m.created_by
                left outer join prices p on p.grocery_id = g.id 
                    and p.store_id = (select uu.favorite_store from user uu where uu.id = {user_id})
            where m.id = {meal_id}
            group by m.id
            order by m.created_on desc
        '''
        return pd.read_sql_query(sql=sql, con=db).iloc[0]

    # MongoDB query
    else:
        # get favorite store
        store_id = mongo_db['user'].find_one({'_id': user_id}).get('favorite_store')

        # get grocery dictionary
        df_grocery = pd.DataFrame(data=list(mongo_db['grocery'].find()))
        df_grocery['price'] = df_grocery.prices.apply(
            lambda x: float(''.join([str(s['price']) for s in x if int(s['store_id']) == int(store_id)]) or np.nan))
        dict_grocery = df_grocery.set_index('_id').to_dict(orient='index')

        # get meal by id
        df_meal = pd.DataFrame(data=list(mongo_db['meal'].find({'_id': meal_id})))
        df_meal.rename(columns={'_id': 'meal_image', 'ingredients': 'data'}, inplace=True)
        # compute meal summary
        df_meal['ingredients'] = df_meal.data.apply(lambda x: get_the_aggregate(x, 'ingredients', dict_grocery))
        df_meal['quantities'] = df_meal.data.apply(lambda x: get_the_aggregate(x, 'quantities', dict_grocery))
        df_meal['measures'] = df_meal.data.apply(lambda x: get_the_aggregate(x, 'measures', dict_grocery))
        df_meal['protein'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'protein', dict_grocery)) / df_meal['servings'], 1)
        df_meal['carbs'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'carbohydrate', dict_grocery)) / df_meal['servings'], 1)
        df_meal['fat'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'fat', dict_grocery)) / df_meal['servings'], 1)
        df_meal['kcal'] = (4 * df_meal['protein'] + 4 * df_meal['carbs'] + 9 * df_meal['fat']).astype(int)
        df_meal['price'] = round(
            df_meal.data.apply(lambda x: get_the_aggregate(x, 'price', dict_grocery)) / df_meal['servings'], 2)
        df_meal['is_vegan'] = df_meal.data.apply(lambda x: get_the_aggregate(x, 'is_vegan', dict_grocery))
        df_meal['created_by'] = mongo_db['user'].find_one({'_id': int(df_meal['created_by'])}).get('username')
        return df_meal.iloc[0]


def db_query_week_schedule(db, mongo_db, user_id, week_no):
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f'''
            select 
                m.category, 
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {0+7*week_no} day) then m.id end) as Mo,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {1+7*week_no} day) then m.id end) as Tu,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {2+7*week_no} day) then m.id end) as We,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {3+7*week_no} day) then m.id end) as Th,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {4+7*week_no} day) then m.id end) as Fr,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {5+7*week_no} day) then m.id end) as Sa,
                sum(case when s.scheduled_on = date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {6+7*week_no} day) then m.id end) as Su
            from 
                schedule s
                inner join meal m on m.id = s.meal_id
            where 
                s.user_id = {user_id}
            group by m.category
        '''
        df = pd.read_sql_query(sql=sql, con=db, index_col='category')
        for cat in ['breakfast', 'lunch', 'dinner']:
            if cat not in df.index:
                df = df.append(pd.Series(name=cat, dtype='float'))
        return df

    # MongoDB query
    else:
        today = dt.datetime.now()
        monday = pd.to_datetime((today + dt.timedelta(days=-today.weekday() + 7 * week_no)).date())
        sunday = monday + dt.timedelta(days=6)
        schedule = mongo_db['schedule'].find({'user_id': user_id, 'scheduled_on': {'$gte': monday, '$lte': sunday}})

        # transform results into pandas pivot table
        df = pd.DataFrame(list(schedule), columns=['meal_id', 'scheduled_on', 'category'])
        df = df.pivot(index='category', columns='scheduled_on', values='meal_id')

        # rename date columns into week day names
        week_days = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']
        for i, d in enumerate(week_days):
            df[d] = df[monday + dt.timedelta(days=i)] if monday + dt.timedelta(days=i) in df.columns else None
        for cat in ['breakfast', 'lunch', 'dinner']:
            if cat not in df.index:
                df = df.append(pd.Series(name=cat, dtype='float'))
        return df[week_days]


def db_query_all_groceries(db, mongo_db):
    """ query list of all available groceries in database for CreateNewMeal. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = "select distinct id, CONCAT(name, ' (in ', measure, ')') as name from grocery"
        return pd.read_sql_query(sql=sql, con=db)

    # MongoDB query
    else:
        cursor = mongo_db.grocery.find({}, {"id": 1, "name": 1, "measure": 1})
        df = pd.DataFrame(list(cursor))
        df['name'] = df['name'] + str(" (in ") + df['measure'] + str(")")
        del df['measure']
        return df


def db_query_all_stores(db, mongo_db):
    """ query list of all stores in database for UpdateProfileForm. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = "select * from store"
        return pd.read_sql_query(sql=sql, con=db)

    # MongoDB query
    else:
        return pd.DataFrame(list(mongo_db.store.find({}))).rename(columns={'_id': 'id'})


def db_query_scheduled_dates(db, mongo_db, user_id, meal_id):
    """ returns already scheduled dates as a sanity check before adding new meals to the schedule. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"""
                select scheduled_on
                from schedule s
                inner join meal m on m.id = s.meal_id
                where s.user_id = {user_id}
                and m.category = (select mm.category from meal mm where mm.id = {meal_id})
            """
        df = pd.read_sql_query(sql=sql, con=db)
        return [str(d.date()) for d in pd.to_datetime(df.scheduled_on)]

    # MongoDB query
    else:
        cat = mongo_db['meal'].find_one({'_id': meal_id}).get('category')
        df = pd.DataFrame(list(mongo_db.schedule.find(
            {"user_id": user_id, "category": cat}, {"meal_id": 1, "scheduled_on": 1})))
        return list(df['scheduled_on'].astype(str).values) if len(df) else list()


def db_query_next_free_schedule_date(db, mongo_db, user_id, meal_id):
    """ query to find the next free day to schedule this meal """
    currently_scheduled_days = db_query_scheduled_dates(db=db, mongo_db=mongo_db, user_id=user_id, meal_id=meal_id)

    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        for day in pd.date_range(start=pd.to_datetime("today").date(), periods=90).to_pydatetime():
            if not str(day.date()) in currently_scheduled_days:
                return day
        return None

    # MongoDB query
    else:
        for day in pd.date_range(start=pd.to_datetime("today").date(), periods=90).to_pydatetime():
            if not str(day.date()) in currently_scheduled_days:
                return day
        return None


def db_query_daily_recommended_kcal(db, mongo_db, user_id):
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"""
            select id, bmr * activity_factor + goal_adjustment as recommended_kcal
            from (
                select id,
                case when gender = 'M' then 13.7516 * weight + 5.0033 * height - 6.7550 * TIMESTAMPDIFF(YEAR, birthday, CURDATE()) + 66.4730
                     when gender = 'F' then 9.5634 * weight + 1.8496 * height - 4.6756 * TIMESTAMPDIFF(YEAR, birthday, CURDATE()) + 655.0955
                     end as bmr,
                case when activity_level = 1 then 1.2 
                     when activity_level = 2 then 1.375 
                     when activity_level = 3 then 1.55
                     when activity_level = 4 then 1.725
                     when activity_level = 5 then 1.9
                     end as activity_factor,
                case when personal_goal = 1 then -500
                     when personal_goal = 2 then 0
                     when personal_goal = 3 then 500
                     end as goal_adjustment
                from user
            ) as recommendation_params 
            where id = {user_id}
            """
        return pd.read_sql_query(sql=sql, con=db).iloc[0]['recommended_kcal']

    # MongoDB query
    else:
        user = mongo_db['user'].find_one({'_id': user_id})
        if not all([user.get('birthday'), user.get('gender'), user.get('weight'), user.get('height'),
                    user.get('activity_level'), user.get('personal_goal')]):
            return None

        age = (pd.to_datetime("today") - user.get('birthday')) / np.timedelta64(1, 'Y')
        if user.get('gender') == 'M':
            bmr = 13.7516 * user.get('weight') + 5.0033 * user.get('height') - 6.7550 * age + 66.4730
        elif user.get('gender') == 'F':
            bmr = 9.5634 * user.get('weight') + 1.8496 * user.get('height') - 4.6756 * age + 655.0955
        else:
            bmr = 0
        activity_factor = {'1': 1.2, '2': 1.375, '3': 1.55, '4': 1.725, '5': 1.9}.get(user.get('activity_level'))
        goal_adjustment = {'1': -500, '2': 0, '3': 500}.get(user.get('personal_goal'))
        return bmr * activity_factor + goal_adjustment


def db_query_meal_suggestions(db, mongo_db, schedule, target_kcal, week_no):
    """ function to query meal suggestions based on user profile information and already scheduled meals. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = """
                select m.id,
                    m.name,
                    m.category,
                    cast(
                        (4 * sum(i.quantity / g.quantity * g.protein)
                        + 4 * sum(i.quantity / g.quantity * g.carbohydrate)
                        + 4 * sum(i.quantity / g.quantity * g.fat)
                        ) / m.servings as unsigned) as kcal
                from 
                    meal m
                    inner join ingredient i on i.meal_id = m.id
                    inner join grocery g on g.id = i.grocery_id
                group by m.id
            """
        meals = pd.read_sql_query(sql=sql, con=db)

        sql = f"""
                select 'Mo' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {0 + 7 * week_no} day) as date union all
                select 'Tu' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {1 + 7 * week_no} day) as date union all
                select 'We' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {2 + 7 * week_no} day) as date union all
                select 'Th' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {3 + 7 * week_no} day) as date union all
                select 'Fr' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {4 + 7 * week_no} day) as date union all
                select 'Sa' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {5 + 7 * week_no} day) as date union all
                select 'Su' as col, date_add(date_add(curdate(), interval-WEEKDAY(curdate())-0 day), interval {6 + 7 * week_no} day) as date
            """
        weekdays = pd.read_sql_query(sql=sql, con=db).set_index('col')['date'].to_dict()

        suggestions = {}
        for day in ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']:
            for category in ['breakfast', 'lunch', 'dinner']:
                if pd.isnull(schedule.loc[category][day]) and target_kcal:
                    current_kcal = schedule[day].astype('Int64').map(meals.set_index('id')['kcal'].to_dict()).sum()
                    current_planned = schedule[day].count()
                    recommended_kcal = max(0, target_kcal - current_kcal) / (3 - current_planned)
                    meals['delta'] = abs(meals['kcal'] - recommended_kcal)
                    best_meals = meals.loc[meals.category == category].sort_values(by='delta').head(3)
                    suggestions.update({
                        category + day: {
                            'recommended_kcal': recommended_kcal,
                            'date': weekdays.get(day),
                            'meals': tuple(best_meals.id.values),
                            'names': tuple(best_meals.name.values),
                            'kcals': tuple(best_meals.kcal.values)
                        }
                    })
                elif pd.notnull(schedule.loc[category][day]):
                    meal_id = int(schedule.loc[category][day])
                    suggestions.update({
                        category + day: {
                            'recommended_kcal': target_kcal / 3 if target_kcal else None,
                            'date': weekdays.get(day),
                            'meal': meal_id,
                            'name': meals.loc[meals.id == meal_id, 'name'].iloc[0],
                            'kcal': int(meals.loc[meals.id == meal_id, 'kcal'])
                        }
                    })
                else:
                    suggestions.update({
                        category + day: {
                            'date': weekdays.get(day)
                        }
                    })
        return suggestions

    # MongoDB query
    else:
        meals = pd.DataFrame(list(mongo_db['meal'].find()))
        groceries = pd.DataFrame(data=list(mongo_db['grocery'].find()))
        dic = groceries.set_index('_id').to_dict(orient='index')
        meals['protein'] = meals.ingredients.apply(lambda x: get_the_aggregate(x, 'protein', dic)) / meals['servings']
        meals['carbs'] = meals.ingredients.apply(lambda x: get_the_aggregate(x, 'carbohydrate', dic))/meals['servings']
        meals['fat'] = meals.ingredients.apply(lambda x: get_the_aggregate(x, 'fat', dic)) / meals['servings']
        meals['kcal'] = (4 * meals['protein'] + 4 * meals['carbs'] + 9 * meals['fat']).astype(int)

        today = dt.datetime.now()
        monday = pd.to_datetime((today + dt.timedelta(days=-today.weekday() + 7 * week_no)).date())
        weekdays = {d: str((monday + dt.timedelta(days=i)).date())
                    for i, d in enumerate(['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'])}

        suggestions = {}
        for day in ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']:
            for category in ['breakfast', 'lunch', 'dinner']:
                if pd.isnull(schedule.loc[category][day]) and target_kcal:
                    current_kcal = schedule[day].astype('Int64').map(meals.set_index('_id')['kcal'].to_dict()).sum()
                    current_planned = schedule[day].count()
                    recommended_kcal = max(0, target_kcal - current_kcal) / (3 - current_planned)
                    meals['delta'] = abs(meals['kcal'] - recommended_kcal)
                    best_meals = meals.loc[meals.category == category].sort_values(by='delta').head(3)
                    suggestions.update({
                        category + day: {
                            'recommended_kcal': recommended_kcal,
                            'date': weekdays.get(day),
                            'meals': tuple(best_meals['_id'].values),
                            'names': tuple(best_meals['name'].values),
                            'kcals': tuple(best_meals['kcal'].values)
                        }
                    })
                elif pd.notnull(schedule.loc[category][day]):
                    meal_id = int(schedule.loc[category][day])
                    suggestions.update({
                        category + day: {
                            'recommended_kcal': target_kcal / 3 if target_kcal else None,
                            'date': weekdays.get(day),
                            'meal': meal_id,
                            'name': meals.loc[meals['_id'] == meal_id, 'name'].iloc[0],
                            'kcal': int(meals.loc[meals['_id'] == meal_id, 'kcal'])
                        }
                    })
                else:
                    suggestions.update({
                        category + day: {
                            'date': weekdays.get(day)
                        }
                    })
        return suggestions


def db_query_groceries(db, mongo_db, user_id, week_no):
    """ returns grocery shopping list for the selected week on the sidebar of the plan pages. """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f"""
            select 
                g.name,
                sum(i.quantity) as quantity,
                g.measure
            from 
                schedule s
                left outer join ingredient i on s.meal_id = i.meal_id
                inner join grocery g on g.id = i.grocery_id
            where 
                s.user_id = {user_id}
                and s.scheduled_on >= date_add(curdate(), interval-WEEKDAY(curdate())+{0 + 7 * week_no} day)
                and s.scheduled_on <= date_add(curdate(), interval-WEEKDAY(curdate())+{6 + 7 * week_no} day)
            group by 
                g.name, g.measure
        """
        df = pd.read_sql_query(sql=sql, con=db)
        df['quantity'] = df['quantity'].astype(str) + ' ' + df['measure']
        df['quantity'] = df['quantity'].str.replace('.0 ', ' ')
        return df.set_index('name')['quantity'].to_dict()

    # MongoDB query
    else:
        # query current weeks schedule
        today = dt.datetime.now()
        monday = pd.to_datetime((dt.datetime.now() + dt.timedelta(days=-today.weekday() + 7 * week_no)).date())
        sunday = monday + dt.timedelta(days=6)
        schedule = mongo_db['schedule'].find({'user_id': user_id, 'scheduled_on': {'$gte': monday, '$lte': sunday}})

        # get aggregated grocery quantities
        grocery_list = {}
        for meal in schedule:
            ingredients = mongo_db['meal'].find_one({'_id': meal['meal_id']}).get('ingredients')
            for ingredient in ingredients:
                grocery_list[ingredient.get('grocery_id')] = grocery_list.get(ingredient.get('grocery_id'), 0) \
                                                             + ingredient.get('quantity')

        # query grocery names and measures
        grocery_names = pd.DataFrame(list(mongo_db['grocery'].find({}, {'name': 1}))).set_index('_id')['name'].to_dict()
        grocery_measures = pd.DataFrame(list(mongo_db['grocery'].find({}, {'measure': 1}))).set_index('_id')[
            'measure'].to_dict()
        new_grocery_list = {}
        for k, v in grocery_list.items():
            new_grocery_list[grocery_names.get(k)] = str(v).replace('.0', '') + ' ' + grocery_measures.get(k)
        return new_grocery_list


def db_query_report_top_users(db, mongo_db, filter_from='2022-01-01', filter_to='2022-01-31', sort_by='name', limit=5):
    """ """
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f'''
            select id, name, meals_created, meal_popularity, meals_scheduled, vegan_ratio_pct
            from (
                select u.*, count(s.id) as meal_popularity
                from (
                    select u.*, count(s.id) as meals_scheduled, 
                        cast(100 * sum(m.is_vegan) / count(s.id) as unsigned) as vegan_ratio_pct
                    from (
                        select u.id, u.username as name, count(distinct m.id) as meals_created
                        from user u
                        left outer join meal m on m.created_by = u.id 
                            and m.created_on between '{filter_from}' and date_add('{filter_to}', interval 1 day)
                        group by u.id, u.username
                        ) u
                    left outer join schedule s on s.user_id = u.id 
                        and s.scheduled_on between '{filter_from}' and date_add('{filter_to}', interval 1 day)
                    inner join (
                        select m.id, case when sum(g.is_vegan) = count(g.is_vegan) then 1 else 0 end as is_vegan
                        from meal m
                        inner join ingredient i on i.meal_id = m.id
                        inner join grocery g on g.id = i.grocery_id
                        group by m.id
                        ) m on m.id = s.meal_id
                    group by u.id, u.name
                    ) u
                left outer join meal m on m.created_by = u.id
                left outer join schedule s on s.meal_id = m.id 
                    and s.scheduled_on between '{filter_from}' and date_add('{filter_to}', interval 1 day)
                group by u.id, u.name
                ) top_users_report
            order by {sort_by} desc
            limit {limit}
        '''
        return pd.read_sql_query(sql=sql, con=db, index_col='id').fillna(0)

    # MongoDB query
    else:
        pipeline = [
            {
                '$lookup': {
                    'from': 'schedule',
                    'pipeline': [{'$match': {'scheduled_on': {
                        '$gte': pd.to_datetime(filter_from), '$lte': pd.to_datetime(filter_to)+dt.timedelta(days=1)}}}],
                    'localField': '_id',
                    'foreignField': 'user_id',
                    'as': 'user_schedule'
                }
            },
            {
                '$unwind': {
                    'path': '$user_schedule',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$group': {
                    '_id': '$_id',
                    'name': {'$first': '$username'},
                    'meals_scheduled': {'$sum': {'$cond': ['$user_schedule', 1, 0]}},
                    'vegan_ratio_pct': {'$avg': '$user_schedule.is_vegan'}
                }
            },
            {
                '$lookup': {
                    'from': 'meal',
                    'localField': '_id',
                    'foreignField': 'created_by',
                    'as': 'meals'
                }
            },
            {
                '$unwind': {
                    'path': '$meals',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$lookup': {
                    'from': 'schedule',
                    'pipeline': [{'$match': {'scheduled_on': {
                        '$gte': pd.to_datetime(filter_from), '$lte': pd.to_datetime(filter_to)+dt.timedelta(days=1)}}}],
                    'localField': 'meals._id',
                    'foreignField': 'meal_id',
                    'as': 'other_schedule'}
            },
            {
                '$unwind': {
                    'path': '$other_schedule',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$group': {
                    '_id': {'id': '$_id', 'name': '$name', 'meal_name': '$meals.name'},
                    'id': {'$first': '$_id'},
                    'name': {'$first': '$name'},
                    'meals_created': {'$first': '$meals.created_on'},
                    'meals_scheduled': {'$first': '$meals_scheduled'},
                    'meal_popularity': {'$sum': {'$cond': ['$other_schedule', 1, 0]}},
                    'vegan_ratio_pct': {'$first': '$vegan_ratio_pct'},
                }
            },
            {
                '$group': {
                    '_id': '$id',
                    'name': {'$first': '$name'},
                    'meals_created': {'$sum': {'$cond': [{'$and': [
                        {'$gte': ['$meals_created', pd.to_datetime(filter_from)]},
                        {'$lte': ['$meals_created', pd.to_datetime(filter_to)+dt.timedelta(days=1)]}
                        ]}, 1, 0]}},
                    'meal_popularity': {'$sum': '$meal_popularity'},
                    'meals_scheduled': {'$first': '$meals_scheduled'},
                    'vegan_ratio_pct': {'$first': {'$toInt': {'$multiply': ['$vegan_ratio_pct', 100]}}},
                }
            },
            {'$sort': {sort_by: -1}},
            {'$limit': limit}
        ]
        df = pd.DataFrame(list(mongo_db['user'].aggregate(pipeline))).rename(columns={'_id': 'id'})
        return df.set_index('id').fillna(0)


def db_query_report_top_stores(db, mongo_db, filter_from='2022-01-01', filter_to='2022-01-31', sort_by='name', limit=5):
    # MySQL query
    if len(pd.read_sql_query(sql='SHOW Tables', con=db)):
        sql = f'''
            select r.id, name, revenues_ccy, users_selected, scheduled_meals, meal_coverage
            from (
                select 
                    store.id,
                    store.name, 
                    coalesce(round(sum(case when c.coverage = 1 
                        then i.quantity / g.quantity * p.price else 0 end), 2), 0) as revenues_ccy,
                    count(distinct u.id) as users_selected, 
                    count(distinct s.id) as scheduled_meals,
                    count(p.price)
                from 
                    store
                    left outer join user u on u.favorite_store = store.id
                    left outer join schedule s on s.user_id = u.id 
                        and s.scheduled_on between '{filter_from}' and date_add('{filter_to}', interval 1 day)
                    left outer join (
                        select s.store_id, m.meal_id, sum(s.num_ing = m.num_ing) = count(s.num_ing) as coverage
                        from (
                            select store_id, meal_id, count(*) as num_ing
                            from ingredient i
                            inner join prices p on p.grocery_id = i.grocery_id 
                            group by store_id, meal_id
                            ) s
                        left outer join (
                            select meal_id, count(*) as num_ing
                            from ingredient
                            group by meal_id
                            ) m on m.meal_id = s.meal_id
                        group by s.store_id, m.meal_id
                        ) c on c.store_id = store.id and c.meal_id = s.meal_id
                    left outer join ingredient i on i.meal_id = s.meal_id
                    left outer join grocery g on g.id = i.grocery_id
                    left outer join prices p on p.store_id = store.id and p.grocery_id = i.grocery_id
                group by 
                    store.name
                ) r
            left outer join (
                select c.store_id, cast(sum(c.coverage) as unsigned) as meal_coverage
                from (
                    select s.store_id, m.meal_id, sum(s.num_ing = m.num_ing) = count(s.num_ing) as coverage
                    from (
                        select store_id, meal_id, count(*) as num_ing
                        from ingredient i
                        inner join prices p on p.grocery_id = i.grocery_id 
                        group by store_id, meal_id
                        ) s
                    left outer join (
                        select meal_id, count(*) as num_ing
                        from ingredient
                        group by meal_id
                        ) m on m.meal_id = s.meal_id
                    group by s.store_id, m.meal_id
                    ) c
                group by c.store_id
                ) c on r.id = c.store_id
            order by {sort_by} desc
            limit {limit}
        '''
        return pd.read_sql_query(sql=sql, con=db, index_col='id')

    # MongoDB query
    else:
        pipeline = [
            {
                '$lookup': {
                    'from': 'meal',
                    'localField': '_id',
                    'foreignField': 'prices.store_id',
                    'as': 'meals_by_store'
                }
            },
            {
                '$lookup': {
                    'from': 'user',
                    'localField': '_id',
                    'foreignField': 'favorite_store',
                    'as': 'users'
                }
            },
            {
                '$lookup': {
                    'from': 'schedule',
                    'pipeline': [{'$match': {'scheduled_on': {
                        '$gte': pd.to_datetime(filter_from),
                        '$lte': pd.to_datetime(filter_to) + dt.timedelta(days=1)}}}],
                    'localField': 'users._id',
                    'foreignField': 'user_id',
                    'as': 'schedules'
                }
            },
            {
                '$addFields': {
                    'meal_coverage': {'$size': '$meals_by_store'},
                    'users_selected': {'$size': '$users'},
                    'scheduled_meals': {'$size': '$schedules'},
                }
            },
            {
                '$unwind': {
                    'path': '$schedules',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$lookup': {
                    'from': 'meal',
                    'localField': 'schedules.meal_id',
                    'foreignField': '_id',
                    'as': 'meals_by_schedule'
                }
            },
            {
                '$unwind': {
                    'path': '$meals_by_schedule',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$project': {
                    '_id': 1,
                    'name': 1,
                    'meal_coverage': 1,
                    'users_selected': 1,
                    'scheduled_meals': 1,
                    'revenues': {
                        '$filter': {
                            'input': '$meals_by_schedule.prices',
                            'as': 'prices',
                            'cond': {
                                '$eq': ['$$prices.store_id', '$_id']
                            }
                        }
                    },
                }
            },
            {
                '$unwind': {
                    'path': '$revenues',
                    'preserveNullAndEmptyArrays': True
                }
            },
            {
                '$group': {
                    '_id': '$_id',
                    'name': {'$first': '$name'},
                    'revenues_ccy': {'$sum': '$revenues.price'},
                    'users_selected': {'$first': '$users_selected'},
                    'scheduled_meals': {'$first': '$scheduled_meals'},
                    'meal_coverage': {'$first': '$meal_coverage'},
                }
            },
            {'$sort': {sort_by: -1}},
            {'$limit': limit}
        ]

        df = pd.DataFrame(list(mongo_db['store'].aggregate(pipeline))).rename(columns={'_id': 'id'})
        return df.set_index('id').fillna(0)
