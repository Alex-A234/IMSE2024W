from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, BooleanField, DateField, IntegerField, FloatField, \
    SelectField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, NumberRange, Optional
from app.lib.database_functions import db_query_all_groceries, db_query_all_stores


class RegistrationForm(FlaskForm):
    """ Inputs for registration form, i.e. username, email and password twice. """
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(min=4, max=100)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=2, max=100)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    """ Inputs for login form, i.e. username and password. """
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class UpdateProfileForm(FlaskForm):
    """ Allows user to update profile, e.g. picture, birthday, weight, height, etc. """
    from app.main import db, mongo_db
    df = db_query_all_stores(db=db, mongo_db=mongo_db)
    picture = FileField('Update profile picture', validators=[FileAllowed(['jpg', 'png'])])
    birthday = DateField('Your birthday?')
    height = IntegerField('Your height in cm?', validators=[NumberRange(min=50, max=300)])
    weight = IntegerField('Your weight in kg?', validators=[NumberRange(min=20, max=1000)])
    activity_level = SelectField('How active are you?', choices=[(None, ''), (1, 'no exercise'), (2, 'light exercise (1-2 days per week)'), (3, 'moderate exercise (3-5 days per week)'), (4, 'hard exercise (6-7 days per week)'), (5, 'very hard exercise (more than 7 days per week)')])
    personal_goal = SelectField('What is your fitness goal?', choices=[(None, ''), (1, 'loose weight'), (2, 'maintain weight'), (3, 'gain muscle')])
    favorite_store = SelectField('Update your favorite store', choices=list(zip(df.id, df.name.str.title())))
    gender = SelectField('Select gender', choices=[(None, ''), ('F', 'Female'), ('M', 'Male')])
    submit = SubmitField('Update')


class CreateNewMeal(FlaskForm):
    """ Allows user to create a new meal with title, category, image, instructions, ingredients. """
    from app.main import db, mongo_db
    df = db_query_all_groceries(db=db, mongo_db=mongo_db)
    groceries = [('', '')] + list(df[['id', 'name']].to_records(index=False))

    picture = FileField('Add a fancy picture', validators=[DataRequired(), FileAllowed(['jpg'])])
    name = StringField('Title of your meal', validators=[DataRequired(), Length(max=30)])
    category = SelectField('Add a meal category?', choices=[('breakfast', 'Breakfast'), ('lunch', 'Lunch'), ('dinner', 'Dinner')])
    servings = IntegerField('Number of servings', validators=[DataRequired(), NumberRange(min=1)])
    instructions = TextAreaField('Add some instructions', validators=[DataRequired(), Length(min=10, max=2000)])
    # at least one ingredient and quantity is required
    ingredient1 = SelectField('Ingredients', choices=groceries, validators=[DataRequired()])
    quantity1 = FloatField('Quantity', validators=[DataRequired(), NumberRange(min=0.1, max=10000)])
    # following fields can be left empty
    ingredient2 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity2 = FloatField(validators=[Optional()], default='')
    ingredient3 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity3 = FloatField(validators=[Optional()], default='')
    ingredient4 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity4 = FloatField(validators=[Optional()], default='')
    ingredient5 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity5 = FloatField(validators=[Optional()], default='')
    ingredient6 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity6 = FloatField(validators=[Optional()], default='')
    ingredient7 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity7 = FloatField(validators=[Optional()], default='')
    ingredient8 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity8 = FloatField(validators=[Optional()], default='')
    ingredient9 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity9 = FloatField(validators=[Optional()], default='')
    ingredient10 = SelectField(choices=groceries, validators=[Optional()], default='')
    quantity10 = FloatField(validators=[Optional()], default='')
    submit = SubmitField('Create')
