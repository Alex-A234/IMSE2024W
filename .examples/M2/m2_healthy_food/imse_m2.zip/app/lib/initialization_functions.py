import pandas as pd
import numpy as np
from datetime import datetime, timedelta


def sql_drop_all(db):
    """ function to drop all relevant tables from our mysql database design. """

    cursor = db.cursor()
    for table in ['prices', 'ingredient', 'grocery', 'schedule', 'meal', 'user', 'store']:
        cursor.execute(f'DROP TABLE IF EXISTS {table};')
    db.commit()
    cursor.close()
    return None


def sql_create_all(db):
    """ function to create tables for empty mysql database.  """

    sql = '''
        CREATE TABLE store (
            id INTEGER NOT NULL AUTO_INCREMENT,
            name VARCHAR(30) NOT NULL,
            website VARCHAR(200),
            PRIMARY KEY (id),
            UNIQUE (name),
            UNIQUE (website)
        );
        
        CREATE TABLE user (
            id INTEGER NOT NULL AUTO_INCREMENT,
            username VARCHAR(20) NOT NULL,
            email VARCHAR(120) NOT NULL,
            password VARCHAR(120) NOT NULL,
            gender VARCHAR(1),
            birthday DATETIME,
            height INTEGER,
            weight INTEGER,
            activity_level VARCHAR(2),
            personal_goal VARCHAR(2),
            is_admin BOOLEAN,
            favorite_store INTEGER DEFAULT 1,
            recommended_by INTEGER,
            PRIMARY KEY (id),
            UNIQUE (username),
            UNIQUE (email),
            FOREIGN KEY(favorite_store) REFERENCES store (id)
        );
        
        CREATE TABLE meal (
            id INTEGER NOT NULL AUTO_INCREMENT,
            name VARCHAR(30) NOT NULL,
            instructions VARCHAR(2000) NOT NULL,
            category VARCHAR(30) NOT NULL,
            servings INTEGER NOT NULL,
            created_by INTEGER NOT NULL,
            created_on DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE (name),
            FOREIGN KEY(created_by) REFERENCES user (id)
        );
        
        CREATE TABLE schedule (
            id INTEGER NOT NULL AUTO_INCREMENT,
            user_id INTEGER,
            meal_id INTEGER,
            scheduled_on DATE NOT NULL,
            PRIMARY KEY (id),
            FOREIGN KEY(user_id) REFERENCES user (id) ON DELETE CASCADE,
            FOREIGN KEY(meal_id) REFERENCES meal (id) ON DELETE CASCADE
        );
        
        CREATE TABLE grocery (
            id INTEGER NOT NULL AUTO_INCREMENT,
            name VARCHAR(30) NOT NULL,
            protein FLOAT,
            carbohydrate FLOAT,
            fat FLOAT,
            is_vegan BOOLEAN,
            measure VARCHAR(20),
            quantity FLOAT,
            PRIMARY KEY (id),
            UNIQUE (name)
        );
        
        CREATE TABLE ingredient (
            meal_id INTEGER NOT NULL,
            grocery_id INTEGER NOT NULL,
            quantity FLOAT NOT NULL,
            PRIMARY KEY (meal_id, grocery_id),
            FOREIGN KEY(meal_id) REFERENCES meal (id) ON DELETE CASCADE,
            FOREIGN KEY(grocery_id) REFERENCES grocery (id)
        );
        
        CREATE TABLE prices (
            grocery_id INTEGER NOT NULL,
            store_id INTEGER NOT NULL,
            price FLOAT NOT NULL,
            PRIMARY KEY (grocery_id, store_id),
            FOREIGN KEY(grocery_id) REFERENCES grocery (id),
            FOREIGN KEY(store_id) REFERENCES store (id)
        )
        '''
    cursor = db.cursor()
    for sub_query in sql.split(';'):
        cursor.execute(sub_query)
    db.commit()
    cursor.close()
    return None


def sql_fill_sample_data(db):
    """ function to fill mysql database with sample data from csv files. """

    cursor = db.cursor()

    # add stores
    df = pd.read_csv('app/sample_data/stores.csv')
    number_of_stores = len(df)
    sql = 'INSERT INTO store (name, website) VALUES'
    for i, row in df.iterrows():
        sql += f" ('{row['name']}', '{row['website']}'),"
    cursor.execute(sql[:-1] + ';')

    # add users (favorite store randomly)
    np.random.seed(1234)
    df = pd.read_csv('app/sample_data/users.csv')
    sql = 'INSERT INTO user (username, email, password, gender, birthday, height, weight, activity_level, '
    sql += 'personal_goal, favorite_store, is_admin) VALUES'
    for i, row in df.iterrows():
        sql += " ('%s', '%s', '%s', %s, %s, %s, %s, %s, %s, %s, %s)," % (
            row['username'],
            row['email'],
            row['password'],
            f"'{row['gender']}'" if pd.notnull(row['gender']) else 'NULL',
            f"'{pd.to_datetime(row['birthday']).date()}'" if pd.notnull(row['birthday']) else 'NULL',
            int(row['height']) if pd.notnull(row['height']) else 'NULL',
            int(row['weight']) if pd.notnull(row['weight']) else 'NULL',
            f"'{int(row['activity_level'])}'" if pd.notnull(row['activity_level']) else 'NULL',
            f"'{int(row['personal_goal'])}'" if pd.notnull(row['personal_goal']) else 'NULL',
            1 if row['id'] <= 2 else np.random.choice(number_of_stores) + 1,
            row['is_admin'])
    cursor.execute(sql[:-1] + ';')

    # add meals
    df = pd.read_csv('app/sample_data/meals.csv')
    sql = 'INSERT INTO meal (name, category, servings, instructions, created_by) VALUES'
    for i, row in df.iterrows():
        sql += " ('%s', '%s', %d, '%s', %d)," % (
            row['name'].replace("'", r"\'"),
            row['category'],
            row['servings'],
            row['instructions'].replace("'", r"\'"),
            row['created_by']
        )
    cursor.execute(sql[:-1] + ';')

    # add groceries
    df = pd.read_csv('app/sample_data/groceries.csv')
    sql = 'INSERT INTO grocery (name, protein, carbohydrate, fat, is_vegan, measure, quantity) VALUES '
    for i, row in df.iterrows():
        sql += " ('%s', %.2f, %.2f, %.2f, %s, '%s', %.2f)," % (
            row['name'],
            row['protein'],
            row['carbohydrate'],
            row['fat'],
            row['is_vegan'],
            row['measure'],
            row['quantity'])
    cursor.execute(sql[:-1] + ';')

    # add ingredients
    df = pd.read_csv('app/sample_data/ingredients.csv')
    sql = 'INSERT INTO ingredient (meal_id, grocery_id, quantity) VALUES '
    for i, row in df.iterrows():
        sql += " (%d, %d, %.2f)," % (
            row['meal_id'],
            row['grocery_id'],
            row['quantity'])
    cursor.execute(sql[:-1] + ';')

    # add prices (first store given, others randomly)
    np.random.seed(123)
    df = pd.read_csv('app/sample_data/prices.csv')
    sql = 'INSERT INTO prices (grocery_id, store_id, price) VALUES '
    for i, row in df.iterrows():
        sql += " (%d, %d, %.2f)," % (
            row['grocery_id'],
            row['store_id'],
            row['price'])
    cursor.execute(sql[:-1] + ';')

    # calculating normally distributed prices with actual price as mean and increasing variance
    sql = 'INSERT INTO prices (grocery_id, store_id, price) VALUES '
    for j in range(2, number_of_stores + 1):
        for i, row in df.iterrows():
            # to have more interesting reports, we don't add a price for some stores on random groceries
            if np.random.choice(50) < j:
                continue
            price = max(0.01, round(np.random.normal(loc=row['price'], scale=0.05 * j + 0.01), 2))
            sql += " (%d, %d, %.2f)," % (row['grocery_id'], j, price)
    cursor.execute(sql[:-1] + ';')

    # add meals to schedule (randomly)
    np.random.seed(123)
    df1 = pd.read_csv('app/sample_data/users.csv')
    df2 = pd.read_csv('app/sample_data/meals.csv')
    today = datetime.today()
    days_this_week = [today + timedelta(days=i-today.weekday()-7) for i in range(21)]
    sql = 'INSERT INTO schedule (user_id, meal_id, scheduled_on) VALUES '
    for day in days_this_week:
        for category in ['breakfast', 'lunch', 'dinner']:
            for ids in [[1, 2], df1.loc[df1['id'] > 2, 'id'].values]:
                user_id = np.random.choice(ids)
                meal_id = np.random.choice(df2.loc[df2.category == category, 'meal_id'].values)
                sql += " (%d, %d, '%s')," % (user_id, meal_id, day.date())
    cursor.execute(sql[:-1] + ';')

    db.commit()
    cursor.close()
    return None
