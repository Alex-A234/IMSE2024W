import pymongo
import pandas as pd


def reset_mongo_db(mongo_db):
    """ function to reset mongodb. just a sanity check to ensure that we don't keep any old data from previous runs. """
    for col_name in mongo_db.list_collection_names():
        mongo_db[col_name].drop()


def migrate_all(db, mongo_db):
    """ function to query all information from mysql database and move it into mongodb. """
    # query tables from sql
    df_user = pd.read_sql_query(sql='select * from user', con=db)
    df_schedule = pd.read_sql_query(sql='select * from schedule', con=db)
    df_meal = pd.read_sql_query(sql='select * from meal', con=db)
    df_ingredient = pd.read_sql_query(sql='select * from ingredient', con=db)
    df_grocery = pd.read_sql_query(sql='select * from grocery', con=db)
    df_prices = pd.read_sql_query(sql='select * from prices', con=db)
    df_store = pd.read_sql_query(sql='select * from store', con=db)

    # category map
    category_map = df_meal.set_index('id')['category'].to_dict()

    # rename index column and fix datetime format
    df_user.rename(columns={'id': '_id'}, inplace=True)
    df_meal.rename(columns={'id': '_id'}, inplace=True)
    df_grocery.rename(columns={'id': '_id'}, inplace=True)
    df_store.rename(columns={'id': '_id'}, inplace=True)
    df_user['birthday'] = pd.to_datetime(df_user['birthday'])
    df_schedule['scheduled_on'] = pd.to_datetime(df_schedule['scheduled_on'])
    df_schedule['category'] = df_schedule['meal_id'].map(category_map)
    df_schedule.drop('id', axis=1, inplace=True)
    df_meal['created_on'] = pd.to_datetime(df_meal['created_on'])

    # create user collection
    col = mongo_db['user']
    col.create_index([('username', pymongo.ASCENDING)], unique=True)
    users = [row.dropna().to_dict() for _, row in df_user.iterrows()]
    col.insert_many(users)

    # create meal collection
    col = mongo_db['meal']
    col.create_index([('name', pymongo.ASCENDING)], unique=True)
    col.create_index([('created_on', pymongo.ASCENDING)])
    meals = [row.dropna().to_dict() for _, row in df_meal.iterrows()]
    ingredients = {meal_id: group[['grocery_id', 'quantity']].to_dict(orient='records')
                   for meal_id, group in df_ingredient.groupby('meal_id')}

    # adding meal prices for each store
    meal_prices = {}
    for meal_id, ingredient_list in ingredients.items():
        grocery_dict = {i.get('grocery_id'): i.get('quantity') for i in ingredient_list}
        for store_id in set(df_store['_id']):
            df_store_prices = df_prices.loc[
                (df_prices.store_id == store_id) & df_prices.grocery_id.isin(grocery_dict)].copy()
            if len(grocery_dict) != len(df_store_prices):
                continue
            df_store_prices['quantity'] = df_store_prices.grocery_id.map(grocery_dict)
            df_store_prices['base_quantity'] = df_store_prices.grocery_id.map(
                df_grocery.set_index('_id')['quantity'].to_dict())
            meal_price = df_store_prices.eval('price * quantity / base_quantity').sum()
            meal_prices.setdefault(meal_id, []).append({'store_id': store_id, 'price': round(meal_price, 2)})

    # adding key summaries per meal such as kcal, protein, etc.
    key_summaries = {}
    for meal_id, ingredient_list in ingredients.items():
        meal_servings = df_meal.loc[df_meal['_id'] == meal_id, 'servings'].values[0]
        grocery_dict = {i.get('grocery_id'): i.get('quantity') for i in ingredient_list}
        df_key_summary = df_grocery.loc[df_grocery['_id'].isin(grocery_dict)].copy()
        df_key_summary['quantity_meal'] = df_key_summary['_id'].map(grocery_dict)
        for column in ['protein', 'carbohydrate', 'fat']:
            df_key_summary[column] *= df_key_summary['quantity_meal'] / df_key_summary['quantity'] / meal_servings
        df_key_summary['kcal'] = df_key_summary.eval('4 * protein + 4 * carbohydrate + 9 * fat')
        key_summaries[meal_id] = df_key_summary[['kcal', 'protein', 'carbohydrate', 'fat']].sum().astype(int).to_dict()

    for meal in meals:
        meal.update({'ingredients': ingredients.get(meal['_id'])})
        meal.update({'prices': meal_prices.get(meal['_id'])})
        meal.update(key_summaries.get(meal['_id']))
    col.insert_many(meals)

    # create schedule collection
    col = mongo_db['schedule']
    col.create_index([('user_id', pymongo.ASCENDING)])
    col.create_index([('meal_id', pymongo.ASCENDING)])
    col.create_index([('scheduled_on', pymongo.ASCENDING)])
    is_vegan_mapping = df_grocery.set_index('_id')['is_vegan'].to_dict()
    is_vegan_meal = {i: int(all([is_vegan_mapping.get(v.get('grocery_id')) for v in values]))
                     for i, values in ingredients.items()}
    df_schedule['is_vegan'] = df_schedule['meal_id'].map(is_vegan_meal)
    schedules = [row.dropna().to_dict() for col, row in df_schedule.iterrows()]
    col.insert_many(schedules)

    # create grocery collection
    col = mongo_db['grocery']
    groceries = [row.dropna().to_dict() for _, row in df_grocery.iterrows()]
    prices = {grocery_id: group[['store_id', 'price']].to_dict(orient='records')
              for grocery_id, group in df_prices.groupby('grocery_id')}
    for grocery in groceries:
        grocery.update({'prices': prices.get(grocery['_id'])})
    col.insert_many(groceries)

    # create store collection
    col = mongo_db['store']
    col.create_index([('name', pymongo.ASCENDING)], unique=True)
    stores = [row.dropna().to_dict() for _, row in df_store.iterrows()]
    col.insert_many(stores)
    return None
