from flask import Flask, render_template, url_for, flash, redirect, session, request
from functools import wraps
import os
import time
import mysql.connector
import pymongo
from app.lib.initialization_functions import sql_drop_all, sql_create_all, sql_fill_sample_data
from app.lib.migration_functions import reset_mongo_db, migrate_all
from app.lib.database_functions import *


# create flask instance
app = Flask(__name__)
app.config['SECRET_KEY'] = 'some_incredibly_secret_key'
app.config['DB_MIGRATION_STATUS'] = ''


# create empty mysql database
mysql_config = {'user': 'user', 'password': 'password', 'host': 'sql', 'port': '3306', 'database': 'imse_sql_db'}
db = mysql.connector.connect(**mysql_config)


# create empty mongo database
mongo_client = pymongo.MongoClient('mongodb://user:password@mongo:27017/')
mongo_db = mongo_client['imse_mongo_db']
reset_mongo_db(mongo_db=mongo_db)


def is_logged_in(f):
    """ check if user is logged in """
    @wraps(f)
    def wrap(*args, **kwargs):
        if session.get('logged_in'):
            return f(*args, **kwargs)
        else:
            flash(message='Unauthorized. Please log in.', category='danger')
            return redirect(url_for('login'))
    return wrap


def is_database_initialized(f):
    """ check if database has been initialized """
    @wraps(f)
    def wrap(*args, **kwargs):
        if app.config['DB_MIGRATION_STATUS'] in ['SQL', 'NoSQL']:
            return f(*args, **kwargs)
        else:
            flash(message='Unauthorized. Please initialize database.', category='danger')
            return redirect(url_for('reset'))
    return wrap


def is_admin(f):
    """ check if user is logged in and an admin """
    @wraps(f)
    def wrap(*args, **kwargs):
        if session.get('is_admin'):
            return f(*args, **kwargs)
        else:
            flash(message='Unauthorized. Only admins have access to reports or migrate to NoSQL.', category='danger')
            return redirect(url_for('home'))
    return wrap


@app.route('/')
def reset():
    """ initial landing page, which checks if database has been initialized """
    if app.config['DB_MIGRATION_STATUS'] == '':
        session.clear()
        return render_template('reset.html')
    elif session.get('logged_in'):
        return redirect(url_for('home'))
    else:
        return redirect(url_for('login'))


@app.route('/reset_db')
def reset_db():
    """ initialize database """
    if not app.config['DB_MIGRATION_STATUS']:
        app.config['DB_MIGRATION_STATUS'] = 'SQL'
        sql_drop_all(db=db)
        sql_create_all(db=db)
        sql_fill_sample_data(db=db)
        flash(message="SQL Database initialized successfully. You can now login or register.", category='success')
        return redirect(url_for('login'))
    else:
        flash(message="SQL Database has already been initialized.", category='danger')
        return redirect(url_for('home'))


@app.route('/login', methods=['GET', 'POST'])
@is_database_initialized
def login():
    """ user login page to check if user is registered and passwords match """
    from app.lib.forms import LoginForm

    form = LoginForm()
    if form.validate_on_submit():
        user = db_query_first_user(db=db, mongo_db=mongo_db, username=form.username.data)
        if user and (user.get('password') == form.password.data):
            session['logged_in'] = True
            session['user_id'] = user.get('id') or user.get('_id')
            session['username'] = user.get('username')
            session['email'] = user.get('email')
            session['is_admin'] = user.get('is_admin')
            session['db_status'] = app.config['DB_MIGRATION_STATUS']
            flash(message=f'Log in successful!', category='success')
            return redirect(url_for('home'))
        else:
            flash(message="Incorrect username or password. Are you registered yet?", category='danger')
    return render_template('login.html', form=form)


@app.route('/logout')
def logout():
    """ logout current user by clearing current session and redirect to login page """
    session.clear()
    flash(message='You are now logged out.', category='success')
    return redirect(url_for('login'))


@app.route('/register/<int:recommend_id>', methods=['GET', 'POST'])
@app.route('/register', methods=['GET', 'POST'])
@is_database_initialized
def register(recommend_id=None):
    """ register new user by checking if form is valid, username and mail are unique and passwords match """
    from app.lib.forms import RegistrationForm

    form = RegistrationForm()
    if form.validate_on_submit():
        # check username exists
        if db_query_first_user(db=db, mongo_db=mongo_db, username=form.username.data):
            flash(message='That username is taken. Please choose another username.', category='danger')
        # check email exists
        elif db_query_first_user(db=db, mongo_db=mongo_db, email=form.email.data):
            flash(message='That email is taken. Do you already have an account?', category='danger')
        # otherwise, write into db
        else:
            db_insert_new_user(db=db, mongo_db=mongo_db, form=form, recommend_id=recommend_id)
            flash(message=f'Account created. You can now login.', category='success')
            return redirect(url_for('login'))
    return render_template('register.html', form=form)


@app.route('/home')
@is_database_initialized
@is_logged_in
def home():
    return render_template('home.html')


@app.route('/profile', methods=['GET', 'POST'])
@is_database_initialized
@is_logged_in
def profile():
    from app.lib.forms import UpdateProfileForm

    form = UpdateProfileForm()

    # update profile information
    if request.method == 'POST':
        db_update_current_user(db=db, mongo_db=mongo_db, username=session['username'], form=form)
        if form.picture.data:
            _, f_ext = os.path.splitext(form.picture.data.filename)
            form.picture.data.save(f'app/static/img/users/{session["username"] + f_ext}')
        flash(message='Profile information updated.', category='success')
    else:
        user = db_query_first_user(db=db, mongo_db=mongo_db, username=session['username'])
        form.favorite_store.data = str(user.get('favorite_store'))
        form.birthday.data = pd.to_datetime(user.get('birthday'))
        form.gender.data = user.get('gender')
        form.height.data = int(user.get('height')) if user.get('height') else None
        form.weight.data = int(user.get('weight')) if user.get('weight') else None
        form.activity_level.data = user.get('activity_level')
        form.personal_goal.data = user.get('personal_goal')
        if not all([user.get('birthday'),
                    user.get('height'),
                    user.get('weight'),
                    user.get('activity_level'),
                    user.get('personal_goal')]):
            flash(message='Please complete your profile information.', category='info')

    # find user profile picture
    user_files = [f for f in os.listdir('app/static/img/users/') if f.startswith(f"{session['username']}.")]
    if user_files:
        image_file = url_for('static', filename=f'img/users/{user_files[0]}')
    else:
        image_file = url_for('static', filename='img/users/default.png')

    # add sidebar content
    if session['is_admin']:
        timer = time.time()
        db_query_report_top_users(db=db, mongo_db=mongo_db)
        db_query_report_top_stores(db=db, mongo_db=mongo_db)
        report_timer = time.time() - timer

        sidebar = {
            'title': 'DBMS Management',
            'description': 'Below you find some insights about the current DBMS. '
                           + 'Click the "Migrate" button to start migration to NoSQL.',
            'button': 'migrate',
            'data': {'SQL tables': len(pd.read_sql_query(sql='SHOW Tables', con=db)),
                     'NoSQL collections': len(mongo_db.list_collection_names()),
                     'Report query runtime': f'{report_timer * 1000:.1f}ms'}
        }
    else:
        sidebar = {
            'title': 'Recommend our app!',
            'description': 'If you know anyone who might be interested in our website, please share the following link:'
                           + f' <a href="https://localhost:5000/register/{session["user_id"]}">'
                           + f'https://localhost:5000/register/{session["user_id"]}</a>.'
        }
    return render_template('profile.html', image_file=image_file, form=form, sidebar=sidebar)


@app.route('/plan')
@app.route('/plan/<string:last_or_next>')
@is_database_initialized
@is_logged_in
def plan(last_or_next='current'):
    week_no = -1 if last_or_next == 'last' else 1 if last_or_next == 'next' else 0
    # query meal schedule
    df = db_query_week_schedule(db=db, mongo_db=mongo_db, user_id=session['user_id'], week_no=week_no)
    # query target kcal
    target_kcal = db_query_daily_recommended_kcal(db=db, mongo_db=mongo_db, user_id=session['user_id'])
    # query suggested meals
    suggestions = db_query_meal_suggestions(db=db, mongo_db=mongo_db, schedule=df, target_kcal=target_kcal,
                                            week_no=week_no)
    # get grocery list
    grocery_list = db_query_groceries(db=db, mongo_db=mongo_db, user_id=session['user_id'], week_no=week_no)
    # adding source page for images
    img_path = url_for('static', filename='img/meals/default.jpg')
    # defining sidebar content
    sidebar = {
        'title': 'Grocery List',
        'description': 'Here is a summary of all groceries you need for your planned meals that week.',
        'data': grocery_list
    }
    return render_template('plan.html', df=df, img_path=img_path, suggestions=suggestions, last_or_next=last_or_next,
                           sidebar=sidebar)


@app.route('/meals')
@is_database_initialized
@is_logged_in
def meals():
    df = db_query_meals(db=db, mongo_db=mongo_db, user_id=session['user_id'])
    df[['kcal', 'protein', 'carbs', 'fat', 'price']] = df[['kcal', 'protein', 'carbs', 'fat', 'price']].clip(lower=0.01)
    df.fillna('', inplace=True)
    img_path = url_for('static', filename='img/meals/default.jpg')
    # defining sidebar content
    sidebar = {
        'title': 'Summary',
        'description': 'Short summary of all meals and ingredients in our database.',
        'data': {
            'Total number of meals': len(df),
            'Total number of ingredients': len(set([i for ii in df.ingredients for i in ii.split(',')])),
            'Average calories per meal': int(df.kcal.mean())
        }
    }
    return render_template('meals.html', title='Meal', df=df, img_path=img_path, sidebar=sidebar)


@app.route('/meal/<int:meal_id>')
@is_database_initialized
@is_logged_in
def meal(meal_id):
    df = db_query_meal_details(db=db, mongo_db=mongo_db, meal_id=meal_id, user_id=session['user_id'])
    df[['price']] = df[['price']].clip(lower=0.01)
    df.fillna('', inplace=True)
    df['created_on'] = pd.to_datetime(df['created_on'])
    img_path = url_for('static', filename=f'img/meals/{meal_id}.jpg')
    today = pd.to_datetime("today").date()
    return render_template('meal.html', title=df['name'], meal_id=meal_id, img_path=img_path, df=df, today=today)


@app.route('/new_meal', methods=['GET', 'POST'])
@is_database_initialized
@is_logged_in
def new_meal():
    from app.lib.forms import CreateNewMeal

    form = CreateNewMeal()
    if form.validate_on_submit():
        # check meal name exists
        if db_query_first_meal(db=db, mongo_db=mongo_db, name=form.name.data):
            flash(message='Sorry, that meal already exists.', category='danger')
        else:
            meal_id = db_create_new_meal(db=db, mongo_db=mongo_db, user_id=session['user_id'], form=form)

            # save picture
            if form.picture.data:
                _, f_ext = os.path.splitext(form.picture.data.filename)
                form.picture.data.save(f'app/static/img/meals/{str(meal_id) + f_ext}')
            flash(message=f'New meal created.', category='success')
            return redirect(url_for('meals'))
    return render_template('new_meal.html', form=form)


@app.route('/add_schedule/<int:meal_id>', methods=['GET', 'POST'])
@app.route('/add_schedule/<int:meal_id>/<string:selected_date>')
@is_database_initialized
@is_logged_in
def add_schedule(meal_id, selected_date=None):
    if request.method == 'POST':
        if not request.form.get('selected_date'):
            flash(message=f"Please select a date.", category='danger')
            return redirect(url_for('meal', meal_id=meal_id))

        selected_date = pd.to_datetime(request.form.get('selected_date')).to_pydatetime()
        if str(selected_date.date()) in db_query_scheduled_dates(db=db, mongo_db=mongo_db, user_id=session['user_id'],
                                                                 meal_id=meal_id):
            flash(message=f"Sorry, you already scheduled a meal on that day for the same category.", category='danger')
            return redirect(url_for('meal', meal_id=meal_id))

        db_add_to_schedule(db=db, mongo_db=mongo_db, user_id=session['user_id'], meal_id=meal_id,
                           scheduled_on=selected_date)
        flash(message=f"Great, you've added a new meal to your plan on {selected_date.date()}.", category='success')
        return redirect(url_for('plan'))

    # meal added directly via 'Quick Add' or from suggestions
    else:
        if selected_date:
            selected_date = pd.to_datetime(selected_date)
        else:  # just schedule meal for the next free day in schedule
            selected_date = db_query_next_free_schedule_date(db=db, mongo_db=mongo_db, user_id=session['user_id'],
                                                             meal_id=meal_id)

        db_add_to_schedule(db=db, mongo_db=mongo_db, user_id=session['user_id'], meal_id=meal_id,
                           scheduled_on=selected_date)
        flash(message=f"Great, you've added a new meal to your plan on {selected_date.date()}.", category='success')
        return redirect(url_for('plan'))


@app.route('/remove_schedule/<int:meal_id>/<string:selected_date>')
@is_database_initialized
@is_logged_in
def remove_schedule(meal_id, selected_date):
    db_remove_from_schedule(
        db=db, mongo_db=mongo_db, user_id=session['user_id'], meal_id=meal_id, scheduled_on=selected_date)
    flash(message="Meal was removed from your plan.", category='success')
    return redirect(url_for('plan'))


@app.route('/delete_meal/<int:meal_id>')
@is_database_initialized
@is_logged_in
@is_admin
def delete_meal(meal_id):
    db_delete_meal(db=db, mongo_db=mongo_db, meal_id=meal_id)
    flash(message="Meal successfully deleted from our database.", category='success')
    return redirect(url_for('meals'))


@app.route('/report/<string:report_type>', methods=['GET', 'POST'])
@is_database_initialized
@is_logged_in
@is_admin
def report(report_type, filter_from='2022-01-01', filter_to='2022-01-31', sort_by=None):
    # update filter parameters on post request
    if request.method == 'POST':
        filter_from = request.form.get('filter_from')
        filter_to = request.form.get('filter_to')
        sort_by = request.form.get('sort_by')

    # query reports
    if report_type == 'users':
        sort_by = sort_by or 'meals_created'
        df = db_query_report_top_users(db=db, mongo_db=mongo_db, filter_from=filter_from, filter_to=filter_to,
                                       sort_by=sort_by, limit=5)
    else:
        sort_by = sort_by or 'revenues_ccy'
        df = db_query_report_top_stores(db=db, mongo_db=mongo_db, filter_from=filter_from, filter_to=filter_to,
                                        sort_by=sort_by, limit=5)

    # add user or store image path if available
    df['_image_path'] = url_for('static', filename=f'img/{report_type}/default.png')
    for img in [f for f in os.listdir(f'app/static/img/{report_type}/')]:
        df.loc[df['name'] == img.split('.')[0], '_image_path'] = url_for('static', filename=f'img/{report_type}/{img}')

    # add sidebar content
    sidebar = {
        'title': f'Summary selected {report_type}',
        'description': f'Here is a short summary of the <b>row sums</b> for currently filtered {report_type}.',
        'data': {'Total ' + k.replace('ccy', '').replace('_', ' ').title(): int(v) if 'ccy' not in k else str(int(v)) + '€'
                 for k, v in df.sum()[1:4].to_dict().items()}
    }

    return render_template('report.html', df=df, report_type=report_type, filter_from=filter_from, filter_to=filter_to,
                           sort_by=sort_by, sidebar=sidebar)


@app.route('/migrate', methods=['GET', 'POST'])
@is_database_initialized
@is_logged_in
@is_admin
def migrate():
    if app.config['DB_MIGRATION_STATUS'] == 'SQL':
        # migrate to mongodb
        migrate_all(db=db, mongo_db=mongo_db)
        sql_drop_all(db=db)

        # adjust migration status config
        app.config['DB_MIGRATION_STATUS'] = 'NoSQL'
        session['db_status'] = 'NoSQL'
        flash(message=f"Migration to NoSQL completed.", category='success')
        return redirect(url_for('profile'))
    else:
        flash(message="You already migrated to NoSQL.", category='info')
        return redirect(url_for('profile'))
