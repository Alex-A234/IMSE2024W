function myMealFunction() {
  /* Code taken from https://www.w3schools.com/howto/howto_js_filter_table.asp */

  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myMealInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myMealTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td1 = tr[i].getElementsByTagName("td")[1];
    td2 = tr[i].getElementsByTagName("td")[2];
    if (td1 && td2) {
      txtValue1 = td1.textContent || td1.innerText;
      txtValue2 = td2.textContent || td2.innerText;
      if (txtValue1.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else if (txtValue2.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}